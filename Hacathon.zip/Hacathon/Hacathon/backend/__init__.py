"""
Jupiter Smart Swap Backend Services
"""

__version__ = "1.0.0"
__author__ = "Jupiter Smart Swap Team" 