"""
Route Efficiency Analyzer
A Python tool to analyze and visualize the efficiency of token swap routes via Jupiter's Quote API.
"""

__version__ = "1.0.0"
__author__ = "Route Efficiency Analyzer Team" 